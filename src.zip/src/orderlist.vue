<!--
Template Name: order list
Create author: qinglong
Create Time  : 2020-09-20
-->
<template>
  <div class="body" v-if="show">
    <el-page-header @back="()=>this.show=!this.show" content="订单详情">
    </el-page-header>
    <div class="app-content">
      <div class="details">
        <div class="left">
          <el-card header="基本资料:">
            <el-form label-position="left" inline class="demo-table-expand">
              <template v-for="(item,index) in orderDetailFields">
                <el-form-item :label="item.name+':'" :key="index" v-if="item.name !== 'info'">
                  <span>{{ orderDetail[item.prop] }}</span>
                </el-form-item>
              </template>
            </el-form>
          </el-card>
        </div>
        <div class="right">
          <el-card header="信用信息:">
            <el-form label-position="left" inline class="demo-table-expand">
              <template v-for="(item,index) in orderDetailFieldsInfo">
                <el-form-item :label="item.name+':'" :key="index" v-if="item.name !== 'info'">
                  <span>{{ orderDetail.info[item.prop] }}</span>
                </el-form-item>
              </template>
            </el-form>
          </el-card>
        </div>
      </div>
    </div>
  </div>
  <div class="body" v-else>
    <div class="app-search">
      <el-form inline size="small" status-icon>
        <el-form-item prop="name" label="姓名">
          <el-input clearable v-model="search.name" />
        </el-form-item>
        <el-form-item prop="loadPhone" label="手机号">
          <el-input clearable v-model="search.loadPhone" minlength="11" maxlength="11" />
        </el-form-item>
        <el-form-item prop="managerPhone" label="经理手机号">
          <el-input clearable v-model="search.managerPhone" minlength="11" maxlength="11" />
        </el-form-item>
        <el-form-item prop="orderNo" label="订单号">
          <el-input clearable v-model="search.orderNo" minlength="16" maxlength="18" />
        </el-form-item>
        <el-form-item prop="time" label="日期范围">
          <el-date-picker v-model="dateTime" type="datetimerange" @change="setdate" :picker-options="pickerOptions" range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期" align="right">
          </el-date-picker>
        </el-form-item>
        <el-form-item>
          <el-button type="success" @click="getData">搜索</el-button>
        </el-form-item>
      </el-form>
    </div>
    <div class="app-content">
      <el-table tooltip-effect="dark" class="table-box" height="100%" border stripe :data="tableData" v-loading="loading">
        <el-table-column :resizable="false" show-overflow-tooltip width="100px" prop="id" label="ID" align="center" />
        <el-table-column :resizable="false" show-overflow-tooltip width="100px" prop="name" label="姓名" align="center" />
        <el-table-column :resizable="false" show-overflow-tooltip width="250px" prop="order_no" label="订单号" align="center" />
        <el-table-column :resizable="false" show-overflow-tooltip prop="phone" label="手机号" align="center" />
        <el-table-column :resizable="false" show-overflow-tooltip prop="price" label="价格" align="center" />
        <el-table-column :resizable="false" show-overflow-tooltip prop="city_name" label="所在城市" align="center" />
        <el-table-column :resizable="false" show-overflow-tooltip prop="apply_money" label="贷款总额" align="center" />
        <el-table-column :resizable="false" show-overflow-tooltip prop="loan_for" label="贷款天数" align="center" />
        <el-table-column :resizable="false" show-overflow-tooltip prop="loan_days" label="贷款天数" align="center" />
        <el-table-column :resizable="false" show-overflow-tooltip prop="statusname" label="状态" align="center" />
        <el-table-column :resizable="false" width="200px" label="操作" align="center">
          <template slot-scope="scope">
            <el-button type="primary" @click="views(scope.row)">查看订单详情</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div class="app-page">
      <el-pagination background layout="prev, pager, next" :page-size="page.pageSize" :total="page.total" :current-page="page.pageNum + 1" @current-change="currentChange" hide-on-single-page></el-pagination>
    </div>
  </div>
</template>
<script>
import axios from "axios";
axios.defaults.withCredentials = true;
export default {
  name: "orderlist",
  data() {
    return {
      search: {},
      dateTime: [],
      show: true,
      orderDetail: {
        name: "尚晓龙",
        age: "23",
        applyMoney: "2.0万",
        cityName: "平顶山市",
        orderNo: "63356451581501524589144",
        status: 0,
        info:
          '{"insurance":"无","zhima_score":"525","provName":"河南省","cityCode":"410400","tencent_loan":"无","social_security":"无本地社保","house":"有房产，不接受抵押","house_worth":"50万及以下","career_identity":"上班族","worked_month":"6个月以上","provident_fund":"无本地公积金","credit_card_amount":"无","cityName":"平顶山市","car":"无车，准备购买","credit_record":"1年内逾期少于3次且少于90天","loan_days":"12个月","house_type":"经济适用房","countyName":"新华区","provCode":"410000","monthly_income_type":"银行代发","applyMoney":"2000000","zhima":"有","loan_for":"教育培训贷款","monthly_income":"4000-6000元","countyCode":"410402","edu":"大专","company_name":"平顶山居然之家"}',
        houseInfo: "有房产",
        carInfo: "无车产",
        creditCardInfo: "无信用卡",
        phone: "156****3005",
        applyTime: 1598512100000,
        showPhone: false,
        price: 1900,
        payoffOrder: true,
        displayPrice: 3800,
        rank: "2",
        bornAreaName: "平顶山市",
        isPrivatePhone: null,
        manager_id: null,
        manager_nama: null,
        manager_phone: null,
        manager_account: null,
        manager_isFreezed: null,
        order_createDate: null,
        pay_money: null,
        pay_createDate: null,
        pay_type: null
      },
      orderDetailFields: [],
      orderDetailFieldsInfo: [],
      page: { pageNum: 0, pageSize: 30, total: 0 },
      loading: true,
      tableData: [
        {
          id: 89992,
          order_no: "63356451581501524589144",
          channel: "bobojieqian10",
          loan_for: "12",
          name: "尚晓龙",
          phone: "156****3005",
          price: 3800,
          city_name: "平顶山市",
          create_date: "2020-06-06 01:20:37",
          apply_money: 2000000,
          loan_days: 360,
          statusname: "待抢单"
        },
        {
          id: 89993,
          order_no: "68306050521607565516332",
          channel: "77xinyong",
          loan_for: "10",
          name: "王仕和",
          phone: "137****2667",
          price: 3800,
          city_name: "丽江市",
          create_date: "2020-07-29 22:18:46",
          apply_money: 2000000,
          loan_days: 720,
          statusname: "待抢单"
        },
        {
          id: 89994,
          order_no: "68326955571800622547772",
          channel: "shantaojie",
          loan_for: "7",
          name: "李彤",
          phone: "130****2963",
          price: 3800,
          city_name: "深圳市",
          create_date: "2020-06-06 01:20:56",
          apply_money: 3000000,
          loan_days: 360,
          statusname: "待抢单"
        },
        {
          id: 89995,
          order_no: "61306550561100795559776",
          channel: "zhuliqianbao",
          loan_for: "14",
          name: "高志虎",
          phone: "152****4915",
          price: 3800,
          city_name: "温州市",
          create_date: "2020-06-06 01:21:29",
          apply_money: 2000000,
          loan_days: 720,
          statusname: "待抢单"
        },
        {
          id: 89996,
          order_no: "62396658551111596515052",
          channel: "zhuliqianbao",
          loan_for: "7",
          name: "周洋",
          phone: "199****4593",
          price: 3800,
          city_name: "成都市",
          create_date: "2020-06-06 01:24:50",
          apply_money: 5000000,
          loan_days: 180,
          statusname: null
        },
        {
          id: 89997,
          order_no: "67326759521612754568924",
          channel: "liebaojinrong",
          loan_for: "7",
          name: "陆情",
          phone: "183****9374",
          price: 4800,
          city_name: "南宁市",
          create_date: "2020-07-29 22:18:46",
          apply_money: 5000000,
          loan_days: 1080,
          statusname: "待抢单"
        },
        {
          id: 89998,
          order_no: "69316255591132406515516",
          channel: "liebaojinrong",
          loan_for: "7",
          name: "杨巍",
          phone: "150****7097",
          price: 3800,
          city_name: "郑州市",
          create_date: "2020-06-06 01:32:45",
          apply_money: 3000000,
          loan_days: 720,
          statusname: "待抢单"
        },
        {
          id: 89999,
          order_no: "67396150551931883537040",
          channel: "shantaojie02",
          loan_for: "7",
          name: "王烈",
          phone: "134****1573",
          price: 5800,
          city_name: "武汉市",
          create_date: "2020-06-06 01:34:18",
          apply_money: 10000000,
          loan_days: 1080,
          statusname: "已抢"
        },
        {
          id: 90000,
          order_no: "66376156581837885547012",
          channel: "zhuliqianbao",
          loan_for: "7",
          name: "付文军",
          phone: "186****7660",
          price: 4800,
          city_name: "武汉市",
          create_date: "2020-06-06 01:34:24",
          apply_money: 5000000,
          loan_days: 720,
          statusname: "已抢"
        },
        {
          id: 90001,
          order_no: "65386450541441265526656",
          channel: "liebaojinrong",
          loan_for: "15",
          name: "倪振艺",
          phone: "132****3333",
          price: 3800,
          city_name: "九江市",
          create_date: "2020-07-29 22:18:46",
          apply_money: 2000000,
          loan_days: 180,
          statusname: "待抢单"
        },
        {
          id: 90002,
          order_no: "67376251571940833511732",
          channel: "zhuliqianbao",
          loan_for: "7",
          name: "刘琴",
          phone: "187****9551",
          price: 3800,
          city_name: "常德市",
          create_date: "2020-06-06 01:38:28",
          apply_money: 2000000,
          loan_days: 720,
          statusname: "待抢单"
        },
        {
          id: 90003,
          order_no: "61396752521750199574600",
          channel: "shantaojie",
          loan_for: "9",
          name: "梁国强",
          phone: "136****5945",
          price: 3800,
          city_name: "云浮市",
          create_date: "2020-06-06 01:39:59",
          apply_money: 2000000,
          loan_days: 360,
          statusname: "待抢单"
        },
        {
          id: 90004,
          order_no: "61316958501151342527372",
          channel: "zhuliqianbao",
          loan_for: "10",
          name: "黄培生",
          phone: "138****3572",
          price: 4800,
          city_name: "铜陵市",
          create_date: "2020-06-06 01:40:31",
          apply_money: 5000000,
          loan_days: 1080,
          statusname: "待抢单"
        },
        {
          id: 90005,
          order_no: "64386851581955623599204",
          channel: "77xinyong",
          loan_for: "13",
          name: "李福院",
          phone: "199****4300",
          price: 3800,
          city_name: "百色市",
          create_date: "2020-07-29 22:18:46",
          apply_money: 10000000,
          loan_days: 180,
          statusname: "待抢单"
        },
        {
          id: 90006,
          order_no: "67396756561952920526040",
          channel: "shantaojie02",
          loan_for: "7",
          name: "文永东",
          phone: "158****9490",
          price: 5800,
          city_name: "深圳市",
          create_date: "2020-06-06 01:42:56",
          apply_money: 2000000,
          loan_days: 720,
          statusname: "待抢单"
        },
        {
          id: 90007,
          order_no: "64396857501550977578592",
          channel: "yibangdai",
          loan_for: "12",
          name: "李晓芳",
          phone: "137****5003",
          price: 4800,
          city_name: "北京市",
          create_date: "2020-06-06 01:43:14",
          apply_money: 3000000,
          loan_days: 360,
          statusname: "待抢单"
        },
        {
          id: 90008,
          order_no: "69396052551265148597768",
          channel: "77xinyong",
          loan_for: "13",
          name: "张祥耀",
          phone: "189****7055",
          price: 4800,
          city_name: "杭州市",
          create_date: "2020-06-06 01:44:07",
          apply_money: 2000000,
          loan_days: 720,
          statusname: "待抢单"
        },
        {
          id: 90009,
          order_no: "63366853501564474501528",
          channel: "zhuliqianbao",
          loan_for: "7",
          name: "宋会来",
          phone: "139****3520",
          price: 5800,
          city_name: "天津市",
          create_date: "2020-07-29 22:18:46",
          apply_money: 3000000,
          loan_days: 720,
          statusname: "待抢单"
        },
        {
          id: 90010,
          order_no: "68386355501069614546792",
          channel: "zhuliqianbao",
          loan_for: "7",
          name: "郭锦旋",
          phone: "178****3328",
          price: 3800,
          city_name: "梅州市",
          create_date: "2020-06-06 01:46:01",
          apply_money: 2000000,
          loan_days: 720,
          statusname: "待抢单"
        },
        {
          id: 90011,
          order_no: "66306954581271785599568",
          channel: "shuziqianbao",
          loan_for: "7",
          name: "余意",
          phone: "134****4050",
          price: 4800,
          city_name: "武汉市",
          create_date: "2020-07-17 22:03:09",
          apply_money: 2000000,
          loan_days: 90,
          statusname: "待抢单"
        }
      ],
      pickerOptions: {
        shortcuts: [
          {
            text: "最近一周",
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7);
              picker.$emit("pick", [start, end]);
            }
          },
          {
            text: "最近一个月",
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30);
              picker.$emit("pick", [start, end]);
            }
          },
          {
            text: "最近三个月",
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90);
              picker.$emit("pick", [start, end]);
            }
          }
        ]
      }
    };
  },
  created() {
    this.show = false;
  },
  mounted() {
    this.getData();
    this.orderDetailFields = Object.keys(this.orderDetail).map(e => {
      return {
        name: e,
        prop: e
      };
    });
    this.orderDetailFieldsInfo = Object.keys(
      JSON.parse(this.orderDetail.info)
    ).map(e => {
      return {
        name: e,
        prop: e
      };
    });
  },
  methods: {
    setdate() {
      if (this.dateTime) {
        this.search.starTime = this.dateTime[0];
        this.search.endTime = this.dateTime[1];
      } else {
        this.search.starTime = null;
        this.search.endTime = null;
      }
    },
    async views(item) {
      let { data } = await axios("/backend/order/listDetails", {
        params: { orderNo: item.order_no }
      });
      if (data.code == 200) {
        this.orderDetail = data.data;
        this.orderDetailFields = Object.keys(data.data).map(e => {
          return {
            name: e,
            prop: e
          };
        });
      }
      this.show = true;
    },
    async getData() {
      this.loading = true;
      let form =
        (this.search.starTime && this.search.endTime)
          ? { ...this.page, ...this.search }
          : this.search;
      let obj = {};
      Object.keys(form).forEach(e => { if (form[e]) obj[e] = form[e] });
      let { data } = await axios("/backend/order/list", { params: obj });
      if (data.code == 200) {
        this.tableData = data.data.list;
        this.page.total = data.data.total;
        this.page.pageNum = data.data.pageNum;
        this.page.pageSize = data.data.pageSize;
      }
      this.loading = false;
    },
    currentChange(val) {
      this.getData();
      this.page.pageNum = val - 1;
    }
  }
};
</script>
<style lang="less">
.body {
  // display: grid;
  // grid-template-rows: 60px auto 60px;
  display: flex;
  justify-content: flex-start;
  align-items: stretch;
  flex-direction: column;
  overflow: hidden;
  &.active {
    grid-template-rows: 60px auto;
    overflow: hidden;
  }
}
.app-content {
  padding: 0 20px;
  overflow: hidden;
  flex: 1 1 auto;
  .table-box {
    td {
      padding: 5px;
    }
  }
}
.app-search {
  display: flex;
  align-items: center;
  padding-top: 15px;
  padding-left: 20px;
  min-height: 60px;
  height: auto;
  max-height: 120px;
}
.app-page {
  display: flex;
  justify-content: flex-start;
  align-items: center;
  padding-left: 15px;
  height: 65px;
  .el-pagination {
    padding: 0;
  }
}
.el-page-header {
  padding: 20px;
  border-bottom: 1px solid #ccc;
  margin-bottom: 20px;
}
.demo-table-expand {
  font-size: 0;
}
.demo-table-expand label {
  width: 120px;
  color: #99a9bf;
}
.demo-table-expand .el-form-item {
  margin-right: 0;
  margin-bottom: 0;
  width: 50%;
}
.details {
  display: flex;
  justify-content: space-evenly;
  align-items: flex-start;
  > div {
    flex: 1;
    // border: 1px solid #ccc;
    // padding: 20px;
  }
  .right {
    margin-left: 20px;
  }
}
</style>
